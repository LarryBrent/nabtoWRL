﻿//
// pch.h
// Header for standard system include files.
//

#pragma once
//#define PROXY_CLSID $guid4$

#include <SDKDDKVer.h>

#define WIN32_LEAN_AND_MEAN

//Windows Header Files:
#include <windows.h>
#include <assert.h>
#include <tchar.h>
#include <Strsafe.h>

//WRL
#include <wrl\client.h>
#include <wrl\implements.h>
#include <wrl\ftm.h>
#include <wrl\event.h>
#include <wrl\wrappers\corewrappers.h>
#include <wrl\module.h>
