#include <stdlib.h>

#include "pch.h"
#include "NabtoManager.h"
#include "nabto_client_api.h"

#define BUFFER_SIZE 100

namespace NabtoWRL
{
	//p private fields
	nabto_status_t  status;

	IFACEMETHODIMP NabtoManager::Initialize(HSTRING nabtoHomeDir)
	{
		status = nabtoStartup(NULL);
		if (status == NABTO_OK)
		{
			return S_OK;
		}
		return FAILED(-1);
	}

	IFACEMETHODIMP NabtoManager::GetNabtoVersionNumbers(int* major, int* minor)
	{
		status = nabtoVersion(major, minor);
		if (status == NABTO_OK)
		{
			return S_OK;
		}
		return FAILED(-1);
	}

	IFACEMETHODIMP NabtoManager::GetNabtoStatusString(HSTRING* errorRef)
	{
		if (status != NABTO_API_NOT_INITIALIZED)
		{
			const char *resultString = nabtoStatusStr(status);
			
			ConvertCharArrayToStringReference(resultString, errorRef);
			return S_OK;
		}
		else
		{
			return FAILED(-1);
		}
	}

	// private methods
	void NabtoManager::ConvertCharArrayToStringReference(const char* inputCharArray, HSTRING* outputStringReference)
	{
		std::string intermediateString = string(inputCharArray);
		std::wstring wideString = StringToWideString(intermediateString);
		HString str;
		str.Set(wideString.c_str());
		*outputStringReference = str.Detach();
	}

	std::wstring NabtoManager::StringToWideString(const std::string& str)
	{
		int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
		std::wstring wstrTo(size_needed, 0);
		MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
		return wstrTo;
	}
}