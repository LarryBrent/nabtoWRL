#include "pch.h"
#include "NabtoManager.h"

namespace NabtoWRL
{
	IFACEMETHODIMP NabtoManager::Foo(HSTRING someString, IMyCallbackProvider* myCallback)
	{
		myCallback->Call(someString);

		return S_OK;
	}
}